//
//  ViewController.m
//  SCLPickerDemo
//
//  Created by Mac os scl on 16/11/7.
//  Copyright © 2016年 沈春绿. All rights reserved.
//

#import "ViewController.h"
#import "CityPickerView.h"
#import "DJToolBar.h"
#import <CoreLocation/CoreLocation.h>
@interface ViewController ()<UITextFieldDelegate,CLLocationManagerDelegate,NSXMLParserDelegate>{
    UITextField *addressText;
}
@property (nonatomic, weak) CityPickerView *pickerView;
@property (nonatomic,strong) CLLocationManager *locationManager;
@property (nonatomic,strong) CLPlacemark *address1;
@property (nonatomic,strong) NSString *address;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor=[UIColor whiteColor];
    self.title=@"城市选择器";
    addressText=[[UITextField alloc]initWithFrame:CGRectMake(20, 120, self.view.bounds.size.width-40, 50)];
    addressText.backgroundColor=[UIColor redColor];
    addressText.delegate=self;
    addressText.borderStyle=UITextBorderStyleBezel;
    addressText.placeholder = @"请输入详细地址…";
    [self.view addSubview:addressText];
    
    [self setupPickerView];
}
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    [self.pickerView update:_address];
}
- (void)setupPickerView{
    CityPickerView *pickerView = [[CityPickerView alloc] init];
    pickerView.bounds = CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height * 0.3);
    self.pickerView = pickerView;
    
    //创建工具条
    DJToolBar *toolbar=[[DJToolBar alloc]init];
    
    toolbar.cancel.target = self;
    toolbar.cancel.action = @selector(cancelAddressClick:);
    toolbar.confirm.target = self;
    toolbar.confirm.action = @selector(confirmAddressClick:);
    addressText.inputView = self.pickerView;
    addressText.inputAccessoryView = toolbar;
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self location];
}
-(CLLocationManager *)locationManager {
    if (!_locationManager) {
        _locationManager = [[CLLocationManager alloc] init];
        _locationManager.distanceFilter = 1.f;
        _locationManager.desiredAccuracy = kCLLocationAccuracyBest;
        _locationManager.delegate = self;
    }
    return _locationManager;
}

-(void) location {
    [self.locationManager requestWhenInUseAuthorization];
    [self.locationManager startUpdatingLocation];
    
    if ([UIDevice currentDevice].systemVersion.floatValue >= 8.0) {
        [self.locationManager requestAlwaysAuthorization];
    }
}

-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations {
    [manager stopUpdatingLocation];
    
    CLGeocoder *geocoder = [[CLGeocoder alloc] init];
    [geocoder reverseGeocodeLocation:[locations lastObject] completionHandler:^(NSArray *placemarks, NSError *error) {
        if (placemarks) {
            CLPlacemark *mark = [placemarks firstObject];
            self.address1 = mark;
            
            //获取城市
            NSString *city = self.address1.locality;
            if (!city) {
                //四大直辖市的城市信息无法通过locality获得，只能通过获取省份的方法来获得（如果city为空，则可知为直辖市）
                city = self.address1.administrativeArea;
            }
            addressText.text = [NSString stringWithFormat:@"%@ %@ %@ %@",self.address1.administrativeArea,self.address1.locality,self.address1.subLocality,self.address1.name];
            //
            _address =[NSString stringWithFormat:@"%@ %@ %@ %@",self.address1.administrativeArea,self.address1.locality,self.address1.subLocality,self.address1.name];
            //详细地址可以用百度的这个
//            BMKAddressComponent *adressCommpoint = result.addressDetail;
//            NSString *adressDetail = [NSString stringWithFormat:@"%@,%@,%@,%@",
//                                      adressCommpoint.province,省
//                                      adressCommpoint.city,市
//                                      adressCommpoint.district,区
//                                      adressCommpoint.streetName 街道
//                                      //,adressCommpoint.streetNumber
//                                      ];
        }
    }];
}

/**
 ************************ 取消选择地址 *******************************
 */
- (void)cancelAddressClick:(UIBarButtonItem *)cancel{
    [addressText endEditing:YES];
}
/**
 ************************ 确定选择地址 *******************************
 */
- (void)confirmAddressClick:(UIBarButtonItem *)confirm{
    addressText.text = [NSString stringWithFormat:@"%@",self.pickerView.address];
    [addressText endEditing:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
