//
//  DJToolBar.h
//  DJCC
//
//  Created by 段振伟 on 16/5/19.
//  Copyright © 2016年 wapushidai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DJToolBar : UIToolbar
@property (nonatomic, strong) UIBarButtonItem *cancel;
@property (nonatomic, strong) UIBarButtonItem *confirm;
@end
