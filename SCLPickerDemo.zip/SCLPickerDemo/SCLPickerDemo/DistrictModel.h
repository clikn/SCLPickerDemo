//
//  SCLAddressModel.h
//  SCLPickerDemo
//
//  Created by Mac os scl on 16/11/7.
//  Copyright © 2016年 沈春绿. All rights reserved.
//
#import <Foundation/Foundation.h>

@interface DistrictModel : NSObject
@property (nonatomic, copy) NSString *districtName;
@property (nonatomic, assign) NSInteger zipcode;
@end
