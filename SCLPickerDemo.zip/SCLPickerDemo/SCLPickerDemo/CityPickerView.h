//
//  CityPickerView.h
//  SCLPickerDemo
//
//  Created by Mac os scl on 16/11/7.
//  Copyright © 2016年 沈春绿. All rights reserved.
//

#import <UIKit/UIKit.h>
@class SCLAddressModel;
@interface CityPickerView : UIPickerView<UIPickerViewDelegate,UIPickerViewDataSource>
/** 省份数据 **/
@property (nonatomic, strong) NSArray *provinceData;
/** 城市数据 **/
@property (nonatomic, strong) NSArray *cityData;
/** 区县数据 **/
@property (nonatomic, strong) NSArray *districtData;
/** 地址模型 **/
@property (nonatomic, strong) SCLAddressModel *address;
- (void)update:(NSString*)address;
@end
