//
//  CityPickerView.m
//  SCLPickerDemo
//
//  Created by Mac os scl on 16/11/7.
//  Copyright © 2016年 沈春绿. All rights reserved.
//

#import "CityPickerView.h"
#import "SCLAddressModel.h"
#import "ProvinceModel.h"
#import "CityModel.h"
#import "DistrictModel.h"
#import "GDataXMLNode.h"
@implementation CityPickerView
- (NSArray *)provinceData{
    if (_provinceData == nil) {
        _provinceData = [NSArray array];
    }
    return _provinceData;
}
- (NSArray *)cityData{
    if (_cityData == nil) {
        _cityData = [NSArray array];
    }
    return _cityData;
}
- (NSArray *)districtData{
    if (_districtData == nil) {
        _districtData = [NSArray array];
    }
    return _districtData;
}
- (SCLAddressModel *)address{
    if (_address == nil) {
        _address = [[SCLAddressModel alloc] init];
    }
    return _address;
}
- (instancetype)init{
    self = [super init];
    if (self) {
        [self parserProvinceData];
        self.dataSource = self;
        self.delegate = self;
    }
    return self;
}
- (void)update:(NSString *)address{
    NSLog(@"=====[%@]",address);
    if (!address) {
        return;
    }
    NSArray *addstr = [address componentsSeparatedByString:@" "];
    for (int x=0; x<self.provinceData.count; x++) {
        if ([((ProvinceModel*)[self.provinceData objectAtIndex:x]).provinceName isEqualToString:addstr[0]]) {
            ProvinceModel *proModel = self.provinceData[x];
            self.cityData = proModel.cityArray;
            [self selectRow:x inComponent:0 animated:YES];//
            [self reloadComponent:1];
            for (int y=0; y<self.cityData.count; y++) {
                if ([((CityModel*)[self.cityData objectAtIndex:y]).cityName isEqualToString:addstr[1]]) {
                    CityModel *cityModel = self.cityData[y];
                    self.districtData = cityModel.districtArray;
                    
                    [self selectRow:y inComponent:1 animated:YES];//
                    [self reloadComponent:2];
                    for (int z=0; z<self.districtData.count; z++) {
                        if ([((DistrictModel*)[self.districtData objectAtIndex:z]).districtName isEqualToString:addstr[2]]) {
                            NSLog(@"---%d:%@",z,addstr[2]);
                            [self selectRow:z inComponent:2 animated:YES];//
                            break;
                        }
                    }
                    break;
                }
//                [self.districtData enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
//                    if ([((DistrictModel*)[self.districtData objectAtIndex:idx]).districtName isEqualToString:addstr[2]]) {
//                        NSLog(@"---%ld:%@",idx,addstr[2]);
//                         [self selectRow:idx inComponent:2 animated:YES];//
//                    }
//                    *stop=YES;
//                }];
            }
            self.address.province = addstr[0];
            self.address.city = addstr[1];
            self.address.district = addstr[2];
            break;
        }
    }
}
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 3;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    switch (component) {
        case 0:
            return self.provinceData.count;
            break;
        case 1:
        {
            return self.cityData.count;
            break;
        }
        case 2:
        {
            return self.districtData.count;
            break;
        }
        default:
            return 0;
            break;
    }
}

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view{
    UILabel* pickerLabel = (UILabel*)view;
    if (!pickerLabel){
        pickerLabel = [[UILabel alloc] init];
        //        pickerLabel.minimumScaleFactor = 8.0;
        [pickerLabel setFont:[UIFont boldSystemFontOfSize:15]];
        pickerLabel.adjustsFontSizeToFitWidth = YES;
        [pickerLabel setTextAlignment:NSTextAlignmentCenter];
        [pickerLabel setBackgroundColor:[UIColor clearColor]];
        
    }
    pickerLabel.text= [self pickerView:pickerView titleForRow:row forComponent:component];
    return pickerLabel;
}
/**
 ************************ 标题 *******************************
 */
- (nullable NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    switch (component) {
        case 0:
        {
            ProvinceModel *proModel = self.provinceData[row];
            return proModel.provinceName;
            break;
        }
        case 1:
        {
            CityModel *cityModel = self.cityData[row];
            return cityModel.cityName;
            break;
        }
        case 2:
        {
            DistrictModel *disModel = self.districtData[row];
            return disModel.districtName;
            break;
        }
        default:
            return  @"";
            break;
    }
}
/**
 ************************ 选择效果 *******************************
 */
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    
    switch (component) {
        case 0:
        {
            ProvinceModel *proModel = self.provinceData[row];
            self.cityData = proModel.cityArray;
            
            CityModel *cityModel = proModel.cityArray[0];
            self.districtData = cityModel.districtArray;
            
            DistrictModel *disModel = cityModel.districtArray[0];
    
            [self reloadComponent:1];
            [self selectRow:0 inComponent:1 animated:YES];
            [self reloadComponent:2];
            [self selectRow:0 inComponent:2 animated:YES];
            
            self.address.province = proModel.provinceName;
            self.address.city = cityModel.cityName;
            self.address.district = disModel.districtName;
            
        }
            break;
        case 1:{
            ProvinceModel *proModel = self.provinceData[[self selectedRowInComponent:0]];
            CityModel *cityModel = proModel.cityArray[row];
            DistrictModel *disModel = cityModel.districtArray[0];
            self.districtData = cityModel.districtArray;
            
            [self reloadComponent:2];
            [self selectRow:0 inComponent:2 animated:YES];
            
            self.address.province = proModel.provinceName;
            self.address.city = cityModel.cityName;
            self.address.district = disModel.districtName;
        }
            break;
        case 2:
        {
            ProvinceModel *proModel = self.provinceData[[self selectedRowInComponent:0]];
            CityModel *cityModel = proModel.cityArray[[self selectedRowInComponent:1]];
            DistrictModel *disModel = cityModel.districtArray[row];
            
            self.address.province = proModel.provinceName;
            self.address.city = cityModel.cityName;
            self.address.district = disModel.districtName;
        }
            break;
            
        default:
            break;
    }
}

- (void)parserProvinceData{
    NSString *path = [[NSBundle mainBundle] pathForResource:@"province_data" ofType:@"xml"];
    NSData *data = [NSData dataWithContentsOfFile:path];
    //对象初始化
    GDataXMLDocument *doc = [[GDataXMLDocument alloc]initWithData:data error:nil];
    //获取根节点
    GDataXMLElement *rootElement = [doc rootElement];
    //获取其他节点
    NSArray *provinceEle = [rootElement elementsForName:@"province"];
    NSMutableArray *provinceModels = [NSMutableArray array];
    
    for (GDataXMLElement *province in provinceEle) {
        // 创建 ProvinceModel
        ProvinceModel *proModel = [[ProvinceModel alloc] init];
        proModel.provinceName = [[province attributeForName:@"name"] stringValue];
        
        NSArray *cityEle = [province elementsForName:@"city"];
        NSMutableArray *cityModels = [NSMutableArray array];
        for (GDataXMLElement *city in cityEle) {
            // 创建 CityModel
            CityModel *cityModel = [[CityModel alloc] init];
            cityModel.cityName = [[city attributeForName:@"name"] stringValue];
            
            NSMutableArray *districtModels = [NSMutableArray array];
            NSArray *districtEle = [city elementsForName:@"district"];
            for (GDataXMLElement *district in districtEle) {
                // 创建 DistrictModel
                DistrictModel *disModel = [[DistrictModel alloc] init];
                disModel.districtName = [[district attributeForName:@"name"] stringValue];
                disModel.zipcode = [[[district attributeForName:@"zipcode"] stringValue] integerValue];
                [districtModels addObject:disModel];
            }
            // CityModel 里面的districtArray属性添加 DistrictModel
            cityModel.districtArray = districtModels;
            [cityModels addObject:cityModel];
        }
        // ProvinceModel 里面的cityArray属性添加 CityModel
        proModel.cityArray = cityModels;
        [provinceModels addObject:proModel];
    }
    
    self.provinceData = provinceModels;
    ProvinceModel *proModel = self.provinceData[0];
    self.cityData = proModel.cityArray;
    CityModel *cityModel = self.cityData[0];
    self.districtData = cityModel.districtArray;
    DistrictModel *disModel = cityModel.districtArray[0];
    
    self.address.province = proModel.provinceName;
    self.address.city = cityModel.cityName;
    self.address.district = disModel.districtName;
}


@end
