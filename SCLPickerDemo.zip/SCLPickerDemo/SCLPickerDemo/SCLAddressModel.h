//
//  SCLAddressModel.h
//  SCLPickerDemo
//
//  Created by Mac os scl on 16/11/7.
//  Copyright © 2016年 沈春绿. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SCLAddressModel : NSObject
/** 省份 **/
@property (nonatomic, copy) NSString *province;
/** 城市 **/
@property (nonatomic, copy) NSString *city;
/** 区县 **/
@property (nonatomic, copy) NSString *district;
@end
