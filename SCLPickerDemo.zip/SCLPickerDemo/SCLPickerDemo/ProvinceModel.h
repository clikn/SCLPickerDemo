//
//  SCLAddressModel.h
//  SCLPickerDemo
//
//  Created by Mac os scl on 16/11/7.
//  Copyright © 2016年 沈春绿. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ProvinceModel : NSObject
@property (nonatomic, copy) NSString *provinceName;
@property (nonatomic, strong) NSArray *cityArray;
@end
