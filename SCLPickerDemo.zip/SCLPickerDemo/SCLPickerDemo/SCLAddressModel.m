//
//  SCLAddressModel.m
//  SCLPickerDemo
//
//  Created by Mac os scl on 16/11/7.
//  Copyright © 2016年 沈春绿. All rights reserved.
//

#import "SCLAddressModel.h"

@implementation SCLAddressModel
- (NSString *)description{
    return [NSString stringWithFormat:@"%@ %@ %@ ",self.province,self.city,self.district];
}
@end
