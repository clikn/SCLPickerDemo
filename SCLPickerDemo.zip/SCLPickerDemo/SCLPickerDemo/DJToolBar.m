//
//  DJToolBar.m
//  DJCC
//
//  Created by 段振伟 on 16/5/19.
//  Copyright © 2016年 wapushidai. All rights reserved.
//

#import "DJToolBar.h"
#define kMainWidth ([[UIScreen mainScreen] bounds].size.width)
@implementation DJToolBar

- (instancetype)init{
    self = [super init];
    if (self) {
        //设置工具条的颜色
        self.barTintColor = [UIColor whiteColor];
        self.backgroundColor = [UIColor whiteColor];
        //设置工具条的frame
        self.frame = CGRectMake(0, 0, kMainWidth, 30);
        
        //给工具条添加按钮
        self.cancel = [[UIBarButtonItem alloc]initWithTitle:@"取消" style:UIBarButtonItemStylePlain target:self action:nil];
        UIBarButtonItem *item2 = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
        self.confirm = [[UIBarButtonItem alloc]initWithTitle:@"完成" style:UIBarButtonItemStylePlain target:self action:nil];
        self.items = @[self.cancel, item2, self.confirm];
    }
    return self;
}

@end
